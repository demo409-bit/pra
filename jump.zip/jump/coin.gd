extends Area2D

func _on_body_entered(body):
	if body.name == "Jumper":
		get_tree().current_scene.update_score()
		queue_free()
