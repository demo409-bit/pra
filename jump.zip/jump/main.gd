extends Node2D

var score = 0
var total_coins = 3
var game_over = false

func _ready():
	$HUD/GameOverLabel.hide()
	$HUD/RestartButton.hide()

func update_score():
	score += 1
	$HUD/ScoreLabel.text = "Coins: " + str(score)

	if score >= total_coins:
		win_game()

func win_game():
	$HUD/WinLabel.show()
	$Jumper.set_physics_process(false)

# 🔥 GAME OVER FUNCTION
func game_over_func():
	game_over = true
	$HUD/GameOverLabel.show()
	$HUD/RestartButton.show()
	$Jumper.set_physics_process(false)

# 🔥 BUTTON CLICK
func _on_restart_button_pressed():
	get_tree().reload_current_scene()

# 🔥 KEY PRESS (R)
func _input(event):
	if event.is_action_pressed("ui_text_submit") or event.is_action_pressed("ui_accept"):
		get_tree().reload_current_scene()

	if event.is_action_pressed("ui_cancel"): # optional
		get_tree().reload_current_scene()

	if event is InputEventKey and event.pressed:
		if event.keycode == KEY_R:
			get_tree().reload_current_scene()


func _on_death_zone_body_entered(body):
	if body.name == "Jumper":
		game_over_func()
