extends CharacterBody2D

const SPEED = 300.0
const JUMP_VELOCITY = -400.0

# VARIABLES FOR DOUBLE JUMP
var jump_count = 0
var max_jumps = 2

var gravity = ProjectSettings.get_setting("physics/2d/default_gravity")

func _physics_process(delta):
	# Add gravity.
	if not is_on_floor():
		velocity.y += gravity * delta
	else:
		# Reset jumps when you touch the floor
		jump_count = 0

	# Handle Jump (Double Jump)
	if Input.is_action_just_pressed("ui_up") and jump_count < max_jumps:
		velocity.y = JUMP_VELOCITY
		jump_count += 1

	# Horizontal Movement
	var direction = Input.get_axis("ui_left", "ui_right")
	if direction:
		velocity.x = direction * SPEED
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)

	move_and_slide()
