extends Node2D

var is_game_over = false

func _ready():
	add_to_group("game")
	$GameOverText.visible = false   # hide at start

func end_game():
	is_game_over = true
	$GameOverText.visible = true    # show text

func _process(delta):
	if is_game_over and Input.is_key_pressed(KEY_R):
		get_tree().reload_current_scene()
