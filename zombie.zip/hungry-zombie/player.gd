extends CharacterBody2D

@export var speed = 200

func _physics_process(delta):
	# Stop movement if game is over
	var game = get_tree().get_first_node_in_group("game")
	if game != null and game.is_game_over:
		return
	
	var direction = Vector2.ZERO
	
	if Input.is_action_pressed("ui_right"):
		direction.x += 1
	if Input.is_action_pressed("ui_left"):
		direction.x -= 1
	if Input.is_action_pressed("ui_down"):
		direction.y += 1
	if Input.is_action_pressed("ui_up"):
		direction.y -= 1
	
	velocity = direction.normalized() * speed
	move_and_slide()
