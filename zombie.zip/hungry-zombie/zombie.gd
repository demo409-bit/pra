extends CharacterBody2D

@export var speed = 100
@onready var player = get_parent().get_node("Player")

var game_over = false

func _physics_process(delta):
	# Stop if game is over
	if game_over:
		return
	
	# If player still exists
	if player != null:
		var direction = (player.global_position - global_position).normalized()
		
		velocity = direction * speed
		move_and_slide()
		
		# Rotate zombie to face player
		rotation = direction.angle()

# Signal from Area2D
func _on_area_2d_body_entered(body):
	if body.name == "Player" and not game_over:
		game_over = true
		get_tree().call_group("game", "end_game")
