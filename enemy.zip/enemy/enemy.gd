
extends Area2D

@export var speed = 200
var direction = 1

func _process(delta):
	position.x += speed * direction * delta

	if position.x > 1000 or position.x < 50:
		direction *= -1

func _on_area_entered(area):
	if area.name == "Player":
		get_parent().end_game()
