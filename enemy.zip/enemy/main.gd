
extends Node2D

var score = 0
var game_over = false

@onready var score_label = $CanvasLayer/ScoreLabel
@onready var game_over_label = $CanvasLayer/GameOverLabel

func _ready():
	score_label.text = "Score: 0"

	game_over_label.visible = false
	win_label.visible = false
	
	
func add_score():
	if game_over:
		return

	score += 1
	score_label.text = "Score: " + str(score)

	if score >= win_score:
		win_game()
		
func win_game():
	game_over = true
	win_label.visible = true
	get_tree().paused = true

func end_game():
	if game_over:
		return
	game_over = true

	game_over_label.visible = true

	get_tree().paused = true

func _input(event):
	if game_over and event.is_action_pressed("restart"):
		get_tree().paused = false
		get_tree().reload_current_scene()


var win_score = 5

@onready var win_label = $CanvasLayer/WinLabel
