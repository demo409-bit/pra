extends Area2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_area_entered(area):
	if area.name == "Player":
		get_parent().add_score()

		var screen_size = get_viewport_rect().size
		position.x = randi_range(200, screen_size.x - 200)
		position.y = randi_range(100, screen_size.y - 100)
